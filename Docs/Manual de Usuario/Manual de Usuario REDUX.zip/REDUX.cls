% Formato %
\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{REDUX}[10/09/2026 Clase REDUX]

% Clase Madre y opciones de clase%
\DeclareOption{report}{\def\REDUX@baseclass{report}}
\DeclareOption{article}{\def\REDUX@baseclass{article}}
\ExecuteOptions{article}
\ProcessOptions\relax
\LoadClass{\REDUX@baseclass}

% Paquetes %
\RequirePackage[utf8]{inputenc}
\RequirePackage{fontawesome5}
\RequirePackage{xparse}
\RequirePackage{pagecolor}
\RequirePackage[T1]{fontenc}
\RequirePackage{helvet}
\renewcommand{\familydefault}{\sfdefault}
\RequirePackage{verbatim}
\RequirePackage[spanish]{babel}
\RequirePackage{setspace}
\RequirePackage{multicol}
\RequirePackage{titlesec}
\RequirePackage{fancyhdr}
\RequirePackage{geometry}
\RequirePackage[table]{xcolor}
\RequirePackage{amssymb}
\RequirePackage{amsmath}
\RequirePackage{nicefrac}
\RequirePackage{cancel}
\RequirePackage{attachfile}
\RequirePackage{etoolbox}
\RequirePackage{graphicx}
\RequirePackage{float}
\RequirePackage{array}
\RequirePackage{booktabs}
\RequirePackage{multirow}
\RequirePackage{longtable}
\RequirePackage{ragged2e}
\RequirePackage{comment}
\RequirePackage{tocloft}
\RequirePackage{appendix}
\RequirePackage{pdflscape}
\RequirePackage{subcaption}
\RequirePackage{rotating}
\RequirePackage{tikz}
\RequirePackage{pgfplots}
\RequirePackage[export]{adjustbox}
\RequirePackage{listings}
\RequirePackage{tabularx}
\RequirePackage{nowidow}
\RequirePackage{natbib}
\RequirePackage{tabularray}
\RequirePackage{enumitem}
\RequirePackage{lastpage}
\RequirePackage{moresize}
\RequirePackage{hyperref}

% Bibliografía %
\bibliographystyle{apalike}

% Unicode %
\input glyphtounicode
\pdfgentounicode=1

% Viudas y Húerfanos %
\setnowidow[3]
\setnoclub[3]

% Ruta de las Imagenes %
\graphicspath{{Imagenes/}}

% Espacios %
\setlength{\lineskip}{3.5pt}
\setlength{\lineskiplimit}{2pt}
\setlength{\parindent}{20pt}
\setlength{\baselineskip}{12pt}
\setlength{\parskip}{3pt}
\setlist{leftmargin=45pt}
\onehalfspacing
\patchcmd{\@makechapterhead}{\vspace*{50\p@}}{}{}{}
\geometry{top=3cm, bottom=3cm, left=2cm, right=2cm}
\setitemize[1]{label=•}

% Tikz %
\usetikzlibrary{
    arrows.meta,
    calc,
    positioning,
    decorations.pathreplacing,
    patterns,
    shapes.geometric,
    babel
}

\AtBeginEnvironment{tikzpicture}{\shorthandoff{<>}}
\AtEndEnvironment{tikzpicture}{\shorthandon{<>}}

\definecolor{redux_dark}{HTML}{1e074b}
\definecolor{redux_darky}{HTML}{4c3078}
\definecolor{redux_middle}{HTML}{7c5ba9}
\definecolor{redux_lighty}{HTML}{ad89db}
\definecolor{redux_light}{HTML}{e1baff}

\titleclass{\subsubsubsection}{straight}[\subsection]

\newcounter{subsubsubsection}[subsubsection]
\renewcommand\thesubsubsubsection{\thesubsubsection.\arabic{subsubsubsection}}
\renewcommand\theparagraph{\thesubsubsubsection.\arabic{paragraph}}

\titleformat{\subsubsubsection}
  {\normalfont\normalsize\bfseries}{\thesubsubsubsection}{1em}{}
\titlespacing*{\subsubsubsection}{0pt}{3.25ex plus 1ex minus .2ex}{1.5ex plus .2ex}

\makeatletter
\renewcommand\paragraph{\@startsection{paragraph}{5}{\z@}%
  {3.25ex \@plus1ex \@minus.2ex}%
  {-1em}%
  {\normalfont\normalsize\bfseries}}
\renewcommand\subparagraph{\@startsection{subparagraph}{6}{\parindent}%
  {3.25ex \@plus1ex \@minus .2ex}%
  {-1em}%
  {\normalfont\normalsize\bfseries}}

\def\toclevel@subsubsubsection{4}
\def\toclevel@paragraph{5}
\def\toclevel@subparagraph{6}

\def\l@subsubsubsection{\@dottedtocline{4}{7em}{4em}}
\def\l@paragraph{\@dottedtocline{5}{10em}{5em}}
\def\l@subparagraph{\@dottedtocline{6}{14em}{6em}}

\makeatother

\setcounter{secnumdepth}{4}
\setcounter{tocdepth}{4}

% Hipervínculos %
\hypersetup{
    colorlinks=true,
    linkcolor=redux_dark,
    filecolor=redux_lighty,
    urlcolor=redux_dark
    }
\urlstyle{same}

% Tablas %
\renewcommand{\arraystretch}{1.2}
\newcolumntype{P}[1]{>{\centering\arraybackslash}p{#1}}

% Código %
\definecolor{codegreen}{rgb}{0,0.6,0}
\definecolor{codegray}{rgb}{0.5,0.5,0.5}
\definecolor{codepurple}{rgb}{0.58,0,0.82}
\definecolor{backcolour}{rgb}{0.95,0.95,0.92}

\lstdefinestyle{REDUX}{
    backgroundcolor=\color{backcolour},
    commentstyle=\color{codegreen},
    keywordstyle=\color{magenta},
    numberstyle=\tiny\color{codegray},
    stringstyle=\color{codepurple},
    basicstyle=\ttfamily\footnotesize,
    breaklines=true,
    breakatwhitespace=false,
    captionpos=b,
    keepspaces=true,
    numbers=none,
    numbersep=5pt,
    showspaces=false,
    showstringspaces=false,
    showtabs=false,
    tabsize=2
}

\lstset{style=REDUX}

\makeatletter

\gdef\REDUX@institution{E.E.S.T. N°7 Quilmes}
\gdef\REDUX@especialidad{Especialidad Aviónica}
\gdef\REDUX@IMPA{Imagenes/IMPA.png}
\gdef\REDUX@logotype{Imagenes/Redux.png}
\gdef\REDUX@subject{}     
\gdef\REDUX@tasktitle{}   
\gdef\REDUX@course{}      
\gdef\REDUX@students{}    
\gdef\REDUX@professor{}   
\gdef\REDUX@hasstudents{0}

\newcommand{\materia}[1]{\gdef\REDUX@subject{#1}}
\newcommand{\titulo}[1]{\gdef\REDUX@tasktitle{#1}}
\newcommand{\curso}[1]{\gdef\REDUX@course{#1}}
\newcommand{\profesor}[1]{\gdef\REDUX@professor{#1}}
\newcommand{\estudiantes}[1]{%
  \gdef\REDUX@students{#1}%
  \gdef\REDUX@hasstudents{1}%
}

\def\REDUX@studentone{}
\def\REDUX@studenttwo{}
\def\REDUX@studentthree{}
\def\REDUX@studentfour{}
\def\REDUX@studentfive{}

\def\REDUX@getfive#1\\#2\\#3\\#4\\#5\@nil{%
  \def\REDUX@studentone{#1}%
  \def\REDUX@studenttwo{#2}%
  \def\REDUX@studentthree{#3}%
  \def\REDUX@studentfour{#4}%
  \def\REDUX@studentfive{#5}%
}

\newcounter{REDUX@studentcount}

\newcommand{\REDUX@countstudents}{%
  \setcounter{REDUX@studentcount}{1}%
  \begingroup
  \def\countaux##1\\##2\@nil{%
    \ifx##2\@empty\else
      \stepcounter{REDUX@studentcount}%
      \countaux##2\@nil%
    \fi
  }%
  \expandafter\countaux\REDUX@students\\\@empty\@nil
  \endgroup
}

\newcommand{\REDUX@displaystudents}{%
  \REDUX@countstudents
  
  \ifnum\value{REDUX@studentcount}=1
    \begin{center}\large\textbf{\REDUX@students}\end{center}
    
  \else\ifnum\value{REDUX@studentcount}=2
    \begin{multicols}{2}
      \centering\large\textbf{\REDUX@students}
    \end{multicols}
    
  \else\ifnum\value{REDUX@studentcount}=3
    \begin{multicols}{3}
      \centering\large\textbf{\REDUX@students}
    \end{multicols}
    
  \else\ifnum\value{REDUX@studentcount}=4
    \begin{multicols}{2}
      \centering\large\textbf{\REDUX@students}
    \end{multicols}
    
  \else\ifnum\value{REDUX@studentcount}=5
    \expandafter\REDUX@getfive\REDUX@students\@nil
    \begin{center}
      \begin{tabular}{ccc}
        \large\textbf{\REDUX@studentone} & \large\textbf{\REDUX@studenttwo} & \large\textbf{\REDUX@studentthree} \\[1.2em]
        \multicolumn{3}{c}{\large\textbf{\REDUX@studentfour} \qquad\qquad \large\textbf{\REDUX@studentfive}}
      \end{tabular}
    \end{center}
    
  \else\ifnum\value{REDUX@studentcount}=6
    \begin{multicols}{3}
      \centering\large\textbf{\REDUX@students}
    \end{multicols}
    
  \else
    \begin{multicols}{2}
      \centering\large\textbf{\REDUX@students}
    \end{multicols}
  \fi\fi\fi\fi\fi\fi
}

\newcommand{\makeCaratula}[1][1]{%
  \begin{titlepage}
    \thispagestyle{empty}
    \pagecolor{white}
    \begin{tikzpicture}[remember picture,overlay]
      \fill[redux_dark] (current page.north west) rectangle ([xshift=0.8cm]current page.south west);
      \fill[redux_lighty] ([xshift=0.8cm]current page.north west) rectangle ([xshift=1.0cm]current page.south west);
      \fill[redux_darky] ([xshift=0cm, yshift=0cm]current page.north west) rectangle ([xshift=1.0cm, yshift=-0.5cm]current page.north west);
    \end{tikzpicture}

    \hspace*{1.2cm}
    \begin{minipage}{0.88\textwidth}
      
    \begin{tikzpicture}[remember picture,overlay]
      \fill[redux_dark] ([xshift=1.2cm]current page.north west) rectangle (current page.north east);
    \end{tikzpicture}

    \vspace*{-0.2cm}
    \noindent
    \begin{minipage}[c]{0.48\textwidth}
      \begin{flushleft}
        \phantom{\includegraphics[width=10.0cm,height=1.8cm,keepaspectratio]{\REDUX@logotype}}
      \end{flushleft}
    \end{minipage}
    \hfill
    \begin{minipage}[c]{0.48\textwidth}
      \begin{flushright}
        \IfFileExists{\REDUX@IMPA}{%
          \includegraphics[width=5cm,height=1.8cm,keepaspectratio]{\REDUX@IMPA}%
        }{\textcolor{white}{\large\textbf{\REDUX@institution}}}
      \end{flushright}
    \end{minipage}

      \vspace{2.2cm}

      \begin{flushleft}
        \noindent
        \IfFileExists{\REDUX@logotype}{%
          \includegraphics[width=7cm]{\REDUX@logotype}%
        }{\textcolor{redux_dark}{\LARGE\textbf{REDUX}}}%
        \par
        \vspace{0.2cm}
        \textcolor{redux_middle}{\rule{3.5cm}{3pt}}\\[0.6cm]

        {\fontsize{32}{38}\selectfont \textbf{\textcolor{redux_dark}{\REDUX@tasktitle}}\par}
        \vspace{0.6cm}
        {\Large \textbf{\textcolor{redux_middle}{\REDUX@especialidad}}\par}
        \vspace{0.3cm}
        {\large \textcolor{gray}{\REDUX@institution} \quad--\quad \textbf{Año \the\year}}
      \end{flushleft}

      \vfill

      \ifnum\REDUX@hasstudents=1\relax
        \begin{minipage}{\textwidth}
          \centering
          \vspace*{1.0cm}
          {\color{redux_dark}\textbf{EQUIPO DE TRABAJO}}\\[0.4cm]
          {\color{redux_dark}
            \REDUX@displaystudents
          }
        \end{minipage}
        \vspace{1.5cm}
      \else
        \vspace{2.0cm}
      \fi

    \end{minipage}

  \end{titlepage}
  
  \clearpage
  \setcounter{page}{1}

  \ifnum#1=0\relax \else
    \ifnum#1=1\relax \tableofcontents\clearpage \else
      \ifnum#1=2\relax \tableofcontents\clearpage \listoffigures\clearpage \else
        \ifnum#1=3\relax \tableofcontents\clearpage \listoftables\clearpage \else
          \ifnum#1=4\relax \tableofcontents\clearpage \listoffigures\clearpage \listoftables\clearpage \else
            \ifnum#1=5\relax \listoffigures\clearpage \listoftables\clearpage \else
              \ifnum#1=6\relax \listoffigures\clearpage \else
                \ifnum#1=7\relax \listoftables\clearpage
                \fi\fi\fi\fi\fi\fi\fi\fi
}

\newcommand{\REDUX@studentsinline}{%
  \begingroup
    \let\\\@comma
    \REDUX@students
  \endgroup
}

\newcommand{\@comma}{,\space}

\AtBeginDocument{%
  \setlength{\headheight}{18pt}
  \pagestyle{fancy}
  \fancyhf{}

  \renewcommand{\headrulewidth}{1.2pt}
  \renewcommand{\headrule}{\hbox to\headwidth{\color{redux_dark}\leaders\hrule height \headrulewidth\hfill}}
  \renewcommand{\footrulewidth}{0.6pt}
  \renewcommand{\footrule}{\hbox to\headwidth{\color{redux_middle}\leaders\hrule height \footrulewidth\hfill}}

  \fancyhead[L]{\textcolor{redux_dark}{\textbf{\REDUX@tasktitle}}}
  \fancyhead[R]{\textcolor{redux_middle}{\small \ifx\REDUX@subject\empty \REDUX@institution \else \REDUX@subject \fi}}

  \fancyfoot[L]{\textcolor{redux_middle}{\small Proyecto REDUX \ifx\REDUX@course\empty\else \ - \REDUX@course\fi}}
  \fancyfoot[R]{\textcolor{redux_dark}{\small \textbf{Página \thepage\ de \pageref*{LastPage}}}}
}

\newcommand{\bibliografia}[1]{%
  \clearpage
  \phantomsection
  \addcontentsline{toc}{chapter}{Bibliografía}
  \bibliography{#1}%
}

\let\imprimirBibliografia\bibliografia

\AtBeginDocument{%
  \ifnum\REDUX@hasstudents=1\relax
    \def\REDUX@author{\REDUX@students}
  \else
    \def\REDUX@author{\REDUX@institution}
  \fi

  \hypersetup{
    pdftitle={\REDUX@tasktitle},
    pdfauthor={\REDUX@author},
    pdfsubject={\REDUX@subject},
    pdfkeywords={\REDUX@subject, \REDUX@especialidad, \REDUX@course},
    pdfcreator={\REDUX@author - \REDUX@institution},
    pdfproducer={\REDUX@institution},
  }
}

\makeatother